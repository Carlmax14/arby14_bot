# Telegram Arbitrage Bot — Setup

## 1. Create the bot
1. Open Telegram, message **@BotFather**.
2. Send `/newbot`, follow the prompts, and copy the token it gives you
   (looks like `123456789:AAExxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`).

## 2. Install dependencies
```bash
pip install -r requirements.txt
```

## 3. Set your token
Either export it as an environment variable:
```bash
export TELEGRAM_BOT_TOKEN="your_token_here"
```
or open `telegram_arb_bot.py` and paste it directly into `BOT_TOKEN` near the top.

## 4. Run it
```bash
python telegram_arb_bot.py
```

## 5. Subscribe
Find your bot on Telegram (search the username you gave BotFather) and send `/start`.
You'll now get automatic alerts every time it finds arbitrage, on the interval set
in `config.json` (default 5 minutes).

## Commands
| Command | What it does |
|---|---|
| `/start` | Subscribe this chat to alerts |
| `/stop` | Unsubscribe |
| `/scan` | Run a scan immediately, reply with results |
| `/status` | Show bankroll, min profit %, interval, subscriber count |
| `/setbankroll <amount>` | Change bankroll used for stake sizing |
| `/setminprofit <pct>` | Change minimum profit % to flag (e.g. `0.5`) |
| `/setinterval <minutes>` | Change auto-scan interval |

## Notes
- Settings persist in `config.json`; subscriber chat IDs persist in `subscribers.json`
  — both are created automatically on first run, in the same folder as the script.
- The full results of the latest scan are always saved to `arb_opportunities.csv`.
- To run this 24/7, use a process manager (`systemd`, `pm2`, `screen`/`tmux`, or a
  small VPS) rather than leaving a terminal open on your laptop.
- Anti-bot measures on bookmaker sites change over time — if a scraper starts
  returning 0 matches, that bookmaker likely updated its API/headers and the
  scraper for it will need a refresh.
